<div class="block_loading">
	<div class="block_title">
		<h1 class="headline">Aguarde.</h1>
		<p class="description">Validando acesso e checando dados...</p>
	</div>
	<img src="../_images/ibi/carregando.gif" height="320" width="310" class="img_loading">
</div>