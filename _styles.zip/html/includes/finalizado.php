<div class="block_loading">
	<div class="block_title">
		
	</div>
	<div class="block_msg_final">
		<h1>Sistema temporariamente inoperante.</h1>
		<p>Pedimos desculpas pelo transtorno, mas nosso sistema encontrou problemas e encontra-se inoperante neste momento.</p>
		<img src="../_images/ibi/fn_loading.gif" width="100" alt="">
		<p>Caso queira realizar uma nova tentativa, nosso sistema normalizará novamente dentro do prazo de 02 (duas) horas.</p>
	</div><!-- block_msg_final -->
</div>