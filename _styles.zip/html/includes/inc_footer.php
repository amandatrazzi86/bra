<div class="block_footer_one">
	<img src="../_images/ibi/footer.jpg" height="102" width="987" alt="">
</div>